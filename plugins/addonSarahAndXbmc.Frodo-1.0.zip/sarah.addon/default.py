import xbmc,xbmcgui                                                                                                                                                                      
import subprocess,os
import urllib2
import xbmcaddon

#Initialize ADDON
settings = xbmcaddon.Addon(id='sarah.addon')

#Initialize ADDON INFORMATION
sarah_port           =  settings.getSetting( "sarah_port" )
sarah_xbmc         =  settings.getSetting( "sarah_xbmc" )
sarah_ip          =  settings.getSetting( "sarah_ip" )
sarah_ip           =  settings.getSetting( "sarah_ip" )
sarah_port           =  settings.getSetting( "sarah_port" )
sarah_xbmc           =  settings.getSetting( "sarah_xbmc" )

#Initialize value for ref.
menu = 0
video = 0
audio = 0
stopmenu = 0

class MyMonitor( xbmc.Monitor ):
    def __init__( self, *args, **kwargs ):
        xbmc.Monitor.__init__( self )

#    def onScreensaverActivated( self ):    
#        print "screensaver Activated"

    def onDatabaseUpdated( self, database ):
        if (str(settings.getSetting("database_updated")) == "Yes"):
                urllib2.urlopen('http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=database_updated' % (sarah_ip, sarah_port, sarah_xbmc))

monitor = MyMonitor()
                                                                                                                                                                                        
class MyPlayer(xbmc.Player):                                                                                                                                                             
                                                                                                                                                                                       
        def __init__ (self):                                                                                                                                                             
                xbmc.Player.__init__(self)
                urllib2.urlopen('http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=xbmc_started' % (sarah_ip, sarah_port, sarah_xbmc))
                if (str(settings.getSetting("debug_mod")) == "Yes"):
                        print('[SARAH] http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=xbmc_started' % (sarah_ip, sarah_port, sarah_xbmc))
                                                                                                                                                                                        
        def onPlayBackStarted(self):
#                xbmc.sleep(300) # it may take some time for xbmc to read tag info after playback started
                if xbmc.Player().isPlayingVideo():
                        if ((str(settings.getSetting("sarah_xbmc")) == "video") or (str(settings.getSetting("sarah_xbmc")) == "music_and_video")):
                                urllib2.urlopen('http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=video_started' % (sarah_ip, sarah_port, sarah_xbmc))
                                if (str(settings.getSetting("debug_mod")) == "Yes"):
                                        print('[SARAH] http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=video_started' % (sarah_ip, sarah_port, sarah_xbmc))
                
                if xbmc.Player().isPlayingAudio():
                        if ((str(settings.getSetting("sarah_xbmc")) == "music") or (str(settings.getSetting("sarah_xbmc")) == "music_and_video")):
                                urllib2.urlopen('http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=audio_started' % (sarah_ip, sarah_port, sarah_xbmc))
                                if (str(settings.getSetting("debug_mod")) == "Yes"):
                                        print('[SARAH] http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=audio_started' % (sarah_ip, sarah_port, sarah_xbmc))
                                
        def onPlayBackEnded(self):                                                                                                                                                       
                if (VIDEO == 1):                                                                                                                                                         
                        if ((str(settings.getSetting("sarah_xbmc")) == "video") or (str(settings.getSetting("sarah_xbmc")) == "music_and_video")):
                                urllib2.urlopen('http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=video_ended' % (sarah_ip, sarah_port, sarah_xbmc))
                                if (str(settings.getSetting("debug_mod")) == "Yes"):
                                        print('[SARAH] http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=video_ended' % (sarah_ip, sarah_port, sarah_xbmc))
                        
                if (AUDIO == 1):
                        if ((str(settings.getSetting("sarah_xbmc")) == "music") or (str(settings.getSetting("sarah_xbmc")) == "music_and_video")):
                                urllib2.urlopen('http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=audio_ended' % (sarah_ip, sarah_port, sarah_xbmc))
                                if (str(settings.getSetting("debug_mod")) == "Yes"):
                                        print('[SARAH] http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=audio_ended' % (sarah_ip, sarah_port, sarah_xbmc))
                                                                                                                                                                                         
        def onPlayBackStopped(self):                                                                                                                                                     
                if (VIDEO == 1):                                                                                                                                                         
                        if ((str(settings.getSetting("sarah_xbmc")) == "video") or (str(settings.getSetting("sarah_xbmc")) == "music_and_video")):
                                urllib2.urlopen('http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=video_stopped' % (sarah_ip, sarah_port, sarah_xbmc))
                                if (str(settings.getSetting("debug_mod")) == "Yes"):
                                        print('[SARAH] http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=video_stopped' % (sarah_ip, sarah_port, sarah_xbmc))
   
                if (AUDIO == 1):
                        if ((str(settings.getSetting("sarah_xbmc")) == "music") or (str(settings.getSetting("sarah_xbmc")) == "music_and_video")):
                                urllib2.urlopen('http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=audio_stopped' % (sarah_ip, sarah_port, sarah_xbmc))
                                if (str(settings.getSetting("debug_mod")) == "Yes"):
                                        print('[SARAH] http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=audio_stopped' % (sarah_ip, sarah_port, sarah_xbmc))
                                                                                                                                                                                          
        def onPlayBackPaused(self):                                                                                                                                                      
                if xbmc.Player().isPlayingVideo():                                                                                                                                       
                        if ((str(settings.getSetting("sarah_xbmc")) == "video") or (str(settings.getSetting("sarah_xbmc")) == "music_and_video")):
                                urllib2.urlopen('http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=video_paused' % (sarah_ip, sarah_port, sarah_xbmc))
                                if (str(settings.getSetting("debug_mod")) == "Yes"):
                                        print('[SARAH] http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=video_paused' % (sarah_ip, sarah_port, sarah_xbmc))
        
                if xbmc.Player().isPlayingAudio():
                        if ((str(settings.getSetting("sarah_xbmc")) == "music") or (str(settings.getSetting("sarah_xbmc")) == "music_and_video")):
                                urllib2.urlopen('http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=audio_paused' % (sarah_ip, sarah_port, sarah_xbmc))
                                if (str(settings.getSetting("debug_mod")) == "Yes"):
                                        print('[SARAH] http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=audio_paused' % (sarah_ip, sarah_port, sarah_xbmc))
                        
        def onPlayBackResumed(self):                                                                                                                                                     
                if xbmc.Player().isPlayingVideo():                                                                                                                                       
                        if ((str(settings.getSetting("sarah_xbmc")) == "video") or (str(settings.getSetting("sarah_xbmc")) == "music_and_video")):
                                urllib2.urlopen('http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=video_resumed' % (sarah_ip, sarah_port, sarah_xbmc))
                                if (str(settings.getSetting("debug_mod")) == "Yes"):
                                        print('[SARAH] http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=video_resumed' % (sarah_ip, sarah_port, sarah_xbmc))

                if xbmc.Player().isPlayingAudio():
                        if ((str(settings.getSetting("sarah_xbmc")) == "music") or (str(settings.getSetting("sarah_xbmc")) == "music_and_video")):
                                urllib2.urlopen('http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=audio_resumed' % (sarah_ip, sarah_port, sarah_xbmc))
                                if (str(settings.getSetting("debug_mod")) == "Yes"):
                                        print('[SARAH] http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=audio_resumed&title=%s&artist=%s' % (sarah_ip, sarah_port, sarah_xbmc))
                                   
player=MyPlayer()                                                                                                                                                                        
                                                                                                                                                                                         
VIDEO = 0

while(not xbmc.abortRequested):

        if xbmc.Player().isPlaying():
                stopmenu = 1
                if xbmc.Player().isPlayingVideo():                                                                                                                                       
                        VIDEO = 1
                        AUDIO = 0
                else:                                                                                                                                                                    
                        VIDEO = 0
                        AUDIO = 1

    
        xbmc.sleep(1000)
urllib2.urlopen('http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=xbmc_ended' % (sarah_ip, sarah_port, sarah_xbmc))
if (str(settings.getSetting("debug_mod")) == "Yes"):
        print('[SARAH] http://%s:%s/sarah/xbmc?action=xbmcstatus&xbmc=%s&status=xbmc_ended' % (sarah_ip, sarah_port, sarah_xbmc))

#!/usr/bin/python
##########IMPORT DES LIBRAIRIES
import xbmc, xbmcgui, time, urllib, sys, os
urllib.getproxies = lambda x = None: {}

########## IMPORT DES PARAMETRES
count = len(sys.argv) - 1
## Url Cam
urlcam="%s" % (sys.argv[1])
## Num fenetre
position = 1
if (count>1) and (count<4):
   if sys.argv[2].isdigit():
      position= int(sys.argv[2])
   else:
      position = 1
if (position<1) or (position>7):
      position = 1

# Dossier pour les images
tempdir=xbmc.translatePath('special://home')
#tempdir=xbmc.translatePath('special://temp')
#tempdir="D:\\"

########## Parametrage des fenetres AVEC COORDONNEES ET TAILLE EN PIXEL
# resolution viewer xbmc: 1280*720
if (position==1):
   x=0
   y=480
   width=320
   height=240
   tempjpg= "%simg1.jpg" % (tempdir)

if (position==2):
   x=320
   y=480
   width=320
   height=240
   tempjpg= "%simg2.jpg" % (tempdir)

if (position==3):
   x=640
   y=480
   width=320
   height=240
   tempjpg= "%simg3.jpg" % (tempdir)

if (position==4):
   x=960
   y=480
   width=320
   height=240
   tempjpg= "%simg4.jpg" % (tempdir)

if (position==5):
   x=0
   y=240
   width=640
   height=480
   tempjpg= "%simg5.jpg" % (tempdir)

if (position==6):
   x=640
   y=240
   width=640
   height=480
   tempjpg= "%simg6.jpg" % (tempdir)

if (position==7):
   x=0
   y=0
   width=1280
   height=720
   tempjpg= "%simg7.jpg" % (tempdir)

########### CREATION DU LECTEUR 
class CamView(xbmcgui.WindowDialog):
   def __init__(self):
       self.image = xbmcgui.ControlImage(x, y, width, height, "",aspectRatio=2 ) #X,Y,tailleX,tailleY,filename,colorKey,aspectRatio,colorDiffuse 
       self.addControl(self.image)
   

viewer = CamView()
viewer.show()
start_time = time.time()
while(time.time() - start_time <= 15): #LE 15 ICI C'EST LE TEMPS D'AFFICHAGE, ICI 15 SECONDES
   urllib.urlretrieve(urlcam, tempjpg)
   viewer.image.setImage("")
   viewer.image.setImage(tempjpg)
   viewer.image.setAnimations([("conditional", "effect=fade start=100 end=100 time=0 condition=true",)])
viewer.close()
del viewer
os.remove(tempjpg) # efface l'image